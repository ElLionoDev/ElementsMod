
package net.mcreator.elements_mod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import net.mcreator.elements_mod.itemgroup.FireModTabItemGroup;
import net.mcreator.elements_mod.ElementsModModElements;

@ElementsModModElements.ModElement.Tag
public class FireBlastSwordItem extends ElementsModModElements.ModElement {
	@ObjectHolder("elements_mod:fire_blast_sword")
	public static final Item block = null;

	public FireBlastSwordItem(ElementsModModElements instance) {
		super(instance, 11);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 2700;
			}

			public float getEfficiency() {
				return 9f;
			}

			public float getAttackDamage() {
				return 6f;
			}

			public int getHarvestLevel() {
				return 2;
			}

			public int getEnchantability() {
				return 14;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(FireItem.block));
			}
		}, 3, 16f, new Item.Properties().group(FireModTabItemGroup.tab).isImmuneToFire()) {
		}.setRegistryName("fire_blast_sword"));
	}
}
