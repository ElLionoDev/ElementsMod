
package net.mcreator.elements_mod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import net.mcreator.elements_mod.itemgroup.FireModTabItemGroup;
import net.mcreator.elements_mod.ElementsModModElements;

@ElementsModModElements.ModElement.Tag
public class FireItem extends ElementsModModElements.ModElement {
	@ObjectHolder("elements_mod:fire")
	public static final Item block = null;

	public FireItem(ElementsModModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(FireModTabItemGroup.tab).maxStackSize(64).rarity(Rarity.COMMON));
			setRegistryName("fire");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
