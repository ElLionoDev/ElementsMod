
package net.mcreator.elements_mod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.HoeItem;

import net.mcreator.elements_mod.itemgroup.FireModTabItemGroup;
import net.mcreator.elements_mod.ElementsModModElements;

@ElementsModModElements.ModElement.Tag
public class FireBlastHoeItem extends ElementsModModElements.ModElement {
	@ObjectHolder("elements_mod:fire_blast_hoe")
	public static final Item block = null;

	public FireBlastHoeItem(ElementsModModElements instance) {
		super(instance, 13);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new HoeItem(new IItemTier() {
			public int getMaxUses() {
				return 8000;
			}

			public float getEfficiency() {
				return 12f;
			}

			public float getAttackDamage() {
				return 28f;
			}

			public int getHarvestLevel() {
				return 5;
			}

			public int getEnchantability() {
				return 20;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(FireItem.block));
			}
		}, 0, 13f, new Item.Properties().group(FireModTabItemGroup.tab).isImmuneToFire()) {
		}.setRegistryName("fire_blast_hoe"));
	}
}
