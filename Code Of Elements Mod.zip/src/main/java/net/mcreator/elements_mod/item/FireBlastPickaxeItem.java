
package net.mcreator.elements_mod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import net.mcreator.elements_mod.itemgroup.FireModTabItemGroup;
import net.mcreator.elements_mod.ElementsModModElements;

@ElementsModModElements.ModElement.Tag
public class FireBlastPickaxeItem extends ElementsModModElements.ModElement {
	@ObjectHolder("elements_mod:fire_blast_pickaxe")
	public static final Item block = null;

	public FireBlastPickaxeItem(ElementsModModElements instance) {
		super(instance, 9);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 8850;
			}

			public float getEfficiency() {
				return 18f;
			}

			public float getAttackDamage() {
				return 10f;
			}

			public int getHarvestLevel() {
				return 5;
			}

			public int getEnchantability() {
				return 100;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(FireItem.block));
			}
		}, 1, 6f, new Item.Properties().group(FireModTabItemGroup.tab).isImmuneToFire()) {
		}.setRegistryName("fire_blast_pickaxe"));
	}
}
